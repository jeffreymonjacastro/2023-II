SuperAwesome - coming-soon / landing Bootstrap template
=============

SuperAwesome is a free responsive, single-page coming-soon template based on Twitter Bootstrap framework. 


License
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/


Features
-----------

* Simple, fat-free HTML and CSS code. You'll deploy your Coming-soon site in 30-60 minutes.
* Responsive design
* Fancy CSS3 animation in the header

Bug tracker
-----------

Found a bug? Please create an issue here on GitHub! 
https://github.com/pozh/SuperAwesome/issues



Credits
-------
* Design and development: **Sergey Pozhilov** - http://pozhilov.com
* Photos used in template: **Unsplash** - http://unsplash.com
* More free templates by Sergey: http://gettemplate.com
